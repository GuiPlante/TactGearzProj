class ReturnRefusalEmail {
    constructor(id, subject, description, sent, sendingDate) {
        this.emailID = id;
        this.emailSubject = subject;
        this.emailDescription = description;
        this.emailSent = sent;
        this.emailSendingDate = sendingDate;
    }
}
