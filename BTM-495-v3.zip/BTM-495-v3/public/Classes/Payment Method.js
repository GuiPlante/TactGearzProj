class PaymentMethod {
    constructor(cardNo, customerID, orderID, cardType, cardholderName, cardCVV, cardholderZIP) {
        this.cardNo = cardNo;
        this.customerID = customerID;
        this.orderID = orderID;
        this.cardType = cardType;
        this.cardholderName = cardholderName;
        this.cardCVV = cardCVV;
        this.cardholderZIP = cardholderZIP;
    }
}
