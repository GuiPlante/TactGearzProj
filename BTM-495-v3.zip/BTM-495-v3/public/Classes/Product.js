class Product {
    constructor(id, name, color, size, price, barCode, weight, category, quantityInStore, quantityInWarehouse, safetyStockLevel) {
        this.productID = id;
        this.productName = name;
        this.productColor = color;
        this.productSize = size;
        this.productPrice = price;
        this.productBarCode = barCode;
        this.productWeight = weight;
        this.productCategory = category;
        this.productQuantityInStore = quantityInStore;
        this.productQuantityInWarehouse = quantityInWarehouse;
        this.productSafetyStockLevel = safetyStockLevel;
        this.product
    }
}

