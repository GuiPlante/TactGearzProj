class ReturnQuestions {
    constructor(questionNumber, question) {
        this.returnQuestionsNumber = questionNumber;
        this.returnQuestionsQuestions = question;
    }
}
