class DefectiveProduct extends Product {
    constructor(id, condition) {
        super();
        this.productID = id;
        this.defectiveProductCondition = condition;
    }
}
