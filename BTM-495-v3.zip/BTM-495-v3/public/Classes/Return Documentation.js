class ReturnDocumentation {
    constructor(id, returnReason) {
        this.returnDocumentationID = id;
        this.returnDocumentationReason = returnReason;
    }
}
