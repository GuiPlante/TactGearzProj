class Employee {
    constructor(id, firstName, lastName, dateOfBirth, hireDate, address, type, department, email, phoneNumber, hourlyRate) {
        this.employeeID = id;
        this.employeeFirstName = firstName;
        this.employeeLastName = lastName;
        this.employeeDateOfBirth = dateOfBirth;
        this.employeeHireDate = hireDate;
        this.employeeAddress = address;
        this.employeeType = type;
        this.employeeDepartment = department;
        this.employeeEmail = email;
        this.employeePhoneNumber = phoneNumber;
        this.employeeHourlyRate = hourlyRate;
    }
}
