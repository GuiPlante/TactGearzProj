class ReturnForm {
    constructor(id, questionSet, answerSet) {
        this._returnFormID = id;
        this._returnFormQuestionSet = questionSet;
        this._returnFormAnswerSet = answerSet;
    }
}

function createReturn() {
    console.log("Creating Return");
}