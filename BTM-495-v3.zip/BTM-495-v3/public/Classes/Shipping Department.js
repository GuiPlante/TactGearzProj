class ShippingDepartment {
    constructor(id, name, phoneNumber, address) {
        this.shippingCompanyID = id;
        this.shippingCompanyName = name;
        this.shippingCompanyPhoneNumber = phoneNumber;
        this.shippingCompanyAddress = address;
    }
}
