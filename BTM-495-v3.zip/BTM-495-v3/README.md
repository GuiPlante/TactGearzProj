1. install https://nodejs.org/en/download
2. install npm install --global yarn

# To setup the app
`yarn`

## To run the app
`node app.js`

## Bonus: To run the app with continuous dev, use nodemon
`npm install -g nodemon`
`nodemon app.js`